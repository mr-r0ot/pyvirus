"""
PyVirus Python Library
Version 1.0.0
Coded by Mohammad Taha Gorji

GitHub: https://GitHub.com/mr-r0ot/PyVirus
PyPi: https://pypi.org/project/PyVirus
"""

from .core import Version, TOOLS, VIRUS
